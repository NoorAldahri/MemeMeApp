//
//  MemesTableViewController.swift
//  MemeMeApp
//
//  Created by Noor Aldahri on 08/08/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class MemesTableViewController: UIViewController ,UITableViewDelegate, UITableViewDataSource{
    
    var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }
    
    @IBAction func addMeme(_ sender: Any) {
        
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! CreateMemeVC
        self.navigationController?.pushViewController(secondVC, animated: true)
        //completion: nil)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.memes.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MemeCell")!
        let meme = self.memes[(indexPath as NSIndexPath).row]
        
        // Set the image and the text
        cell.imageView?.image = meme.memedImage
        cell.textLabel?.text = meme.topText + meme.bottomText
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        
        detailController.image = memes[indexPath.row].memedImage
        
        present(detailController, animated: true, completion: nil)
        
    }
    
}
