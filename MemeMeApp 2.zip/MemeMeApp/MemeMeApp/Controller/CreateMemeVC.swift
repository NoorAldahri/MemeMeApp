//
//  ViewController.swift
//  MemeMeApp
//
//  Created by Noor Aldahri on 25/07/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class CreateMemeVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate{
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var topTextField: UITextField!
    @IBOutlet weak var bottomTextField: UITextField!
    @IBOutlet weak var toolBar: UIToolbar!
    @IBOutlet weak var shareButton: UIBarButtonItem!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tabBarController?.tabBar.isHidden = true
        
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        
        shareButton.isEnabled = false
        
        setupTextField(textField: topTextField)
        setupTextField(textField: bottomTextField)
    }
    
    func setupTextField(textField: UITextField) {
        
        let memeTextAttributes: [NSAttributedString.Key: Any] = [            NSAttributedString.Key.strokeColor: UIColor.black,
                                                                             NSAttributedString.Key.foregroundColor: UIColor.white,
                                                                             NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
                                                                             NSAttributedString.Key.strokeWidth: -4.0
        ]
        
        topTextField.defaultTextAttributes = memeTextAttributes
        bottomTextField.defaultTextAttributes = memeTextAttributes
        
        topTextField.textAlignment = .center
        bottomTextField.textAlignment = .center
        
        topTextField.delegate = self
        bottomTextField.delegate = self
    }
    
    // Chose Image func
    func choseImageFrom(source: UIImagePickerController.SourceType){
        
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = source
        imagePicker.allowsEditing = true
        present(imagePicker, animated: true, completion: nil)
        
    }
    
    // Album button
    @IBAction func pickAnImageFromAlbum(_ sender: Any) {
        choseImageFrom(source: .photoLibrary)
        
    }
    
    // Camera button
    @IBAction func pickAnImageFromCamera(_ sender: Any) {
        choseImageFrom(source: .camera)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            imageView.image = image
            shareButton.isEnabled = true
        }
        dismiss(animated: true, completion: nil)
    }
    
    //Delete the default text
    func textFieldDidBeginEditing(_ textField: UITextField){
        if textField.text == "TOP" && textField == topTextField {
            topTextField.text = ""
        } else  if textField.text == "BOTTOM" && textField == bottomTextField {
            bottomTextField.text = ""
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField.text?.isEmpty ?? true {
            if textField == topTextField {
                textField.text = "TOP"
            } else {
                textField.text = "BOTTOM"
            }
        }
    }
    
    //Return button
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    //When Showing the keyboard
    @objc func keyboardWillShow(_ notification:Notification) {
        
        if bottomTextField.isEditing{
            view.frame.origin.y = -getKeyboardHeight(notification)
        }
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
    //When hidding the keyboard
    @objc func keyboardWillHide(_ notification:Notification) {
        view.frame.origin.y = 0
    }
    
    
    func save() {
        // Create the meme
        
        let meme = Meme(topText: topTextField.text ?? "" , bottomText: bottomTextField.text ?? "", originalImage: imageView.image, memedImage: generateMemedImage())
        
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        appDelegate.memes.append(meme)
    }
    
    func generateMemedImage() -> UIImage {
        
        hideToolBar(true)
        
        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        hideToolBar(false)
        
        return memedImage
    }
    
    func hideToolBar(_ hide: Bool) {
        
        self.toolBar.isHidden = hide
        self.navigationController?.setNavigationBarHidden(hide, animated: true)
        
    }
    
    
    //Cancel button
    @IBAction func cancel(_ sender: Any) {
        
        //        topTextField.text = "TOP"
        //        bottomTextField.text = "BOTTOM"
        //        imageView.image = nil
    }
    
    //Share button
    @IBAction func share(_ sender: Any) {
        
        let sharing = UIActivityViewController(activityItems: [generateMemedImage()], applicationActivities: nil)
        
        sharing.completionWithItemsHandler = { activityType, completed, returnedItems, error -> () in
            if completed{
                self.save()
            }
        }
        self.present(sharing, animated: true, completion: nil)

    }
    
}
