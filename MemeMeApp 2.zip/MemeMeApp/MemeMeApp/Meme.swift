//
//  meme.swift
//  MemeMeApp
//
//  Created by Noor Aldahri on 02/08/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import Foundation

struct Meme {
    
    var topText: String
    var bottomText: String
    var originalImage: UIImage?
    var memedImage: UIImage?
    
}
